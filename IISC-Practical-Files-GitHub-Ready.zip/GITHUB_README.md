# IISC Practical Files

A simple public collection of practical files for quick access during lab work.

## Files

- `1-traffic_light.txt` — PLC Traffic Light
- `2-conveyor_lamp.txt` — Conveyor Warning Lamp + Motor Start After 30 s
- `3-motor_loop.txt` — Motor 10 s ON / 10 s OFF Loop
- `6-analytics.py` — Industrial Temperature Data Analytics
- `README.txt` — Practical and Viva Quick Guide
- `index.html` — Simple download webpage

## Publish with GitHub Pages

1. Create a **public** GitHub repository.
2. Upload all files in this folder.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.
7. GitHub will give you a public website URL.

The website can then be opened from another PC without requiring the visitor to log in to GitHub.
